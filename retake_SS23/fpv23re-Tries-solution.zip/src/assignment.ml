module type Trie = sig
  (* (<is_word>, <children_list>) *)
  type trie = Trie of (bool * (char * trie) list)

  val empty : trie
  val insert : trie -> char list -> trie
  val remove : trie -> char list -> trie
  val contains : trie -> char list -> bool
end

module type Trie_db = functor (Trie : Trie) -> sig
  type t

  val create : unit -> t
  val insert : t -> char list -> unit
  val remove : t -> char list -> unit
  val contains : t -> char list -> bool
end

module type Helpers = sig
  val string_to_char_list : string -> char list
  val char_list_to_string : char list -> string
end

(** Some helper functions you may use in your code or during testing.
    You can use them where you see fit or fully implement your own solutions. *)
module Helpers : Helpers = struct
  (** Converts a [string] to a [char list]. *)
  let string_to_char_list string =
    List.init (String.length string) (String.get string)

  (** Converts a [char list] to a [string]. *)
  let char_list_to_string list = String.concat "" (List.map Char.escaped list)
end

module Trie : Trie = struct
  (* (<is_word>, <children_list>) *)
  type trie = Trie of (bool * (char * trie) list)

  let empty = Trie (false, [])

  let rec contains (Trie (is_word, children)) word =
    if word = [] then is_word
    else
      let word_head = List.hd word in
      let word_tail = List.tl word in
      match List.assoc_opt word_head children with
      | Some trie -> contains trie word_tail
      | None -> false

  let rec insert (Trie (is_word, children)) word =
    if word = [] then Trie (true, children)
    else
      let word_head = List.hd word in
      let word_tail = List.tl word in
      let subtrie =
        match List.assoc_opt word_head children with
        | None -> insert empty word_tail
        | Some subtrie -> insert subtrie word_tail
      in
      let children =
        (word_head, subtrie) :: List.remove_assoc word_head children
      in
      Trie (is_word, children)

  let rec remove (Trie (is_word, children)) word =
    if word = [] then Trie (false, children)
    else
      let word_head = List.hd word in
      let word_tail = List.tl word in
      let children =
        match List.assoc_opt word_head children with
        | None -> children
        | Some subtrie ->
            let subtrie = remove subtrie word_tail in
            if subtrie <> Trie (false, []) then
              (word_head, subtrie) :: List.remove_assoc word_head children
            else List.remove_assoc word_head children
      in
      Trie (is_word, children)
end

module Trie_db : Trie_db =
functor
  (Trie : Trie)
  ->
  struct
    type command =
      | Insert of char list
      | Remove of char list
      | Contains of (char list * bool Event.channel)

    type t = command Event.channel

    let create () =
      let channel = Event.new_channel () in
      let rec server current =
        match Event.sync (Event.receive channel) with
        | Insert word -> server (Trie.insert current word)
        | Remove word -> server (Trie.remove current word)
        | Contains (word, return) ->
            Event.sync (Event.send return (Trie.contains current word));
            server current
      in
      let _ = Thread.create server Trie.empty in
      channel

    let insert trie_server word =
      Event.sync (Event.send trie_server (Insert word))

    let remove trie_server word =
      Event.sync (Event.send trie_server (Remove word))

    let contains trie_server word =
      let return_channel = Event.new_channel () in
      Event.sync (Event.send trie_server (Contains (word, return_channel)));
      Event.sync (Event.receive return_channel)
  end

(* The following tries each contain the words "hey", "hi" and "hi!".
   These should help you understand how the modules and types should be used. *)

(* Usage of the type *)
let example_trie_direct () =
  let open Trie in
  Trie
    ( false,
      [
        ( 'h',
          Trie
            ( false,
              [
                ('e', Trie (false, [ ('y', Trie (true, [])) ]));
                ('i', Trie (true, [ ('!', Trie (true, [])) ]));
              ] ) );
      ] )

(* Usage of the Trie module *)
let example_trie_insert () =
  let trie = Trie.empty in
  let trie = Trie.insert trie (Helpers.string_to_char_list "hey") in
  let trie = Trie.insert trie (Helpers.string_to_char_list "hi") in
  let trie = Trie.insert trie (Helpers.string_to_char_list "hi!") in
  trie

(* Usage of the Trie database module *)
let example_trie_insert_db () =
  let module Trie_db = Trie_db (Trie) in
  let trie = Trie_db.create () in
  Trie_db.insert trie (Helpers.string_to_char_list "hey");
  Trie_db.insert trie (Helpers.string_to_char_list "hi");
  Trie_db.insert trie (Helpers.string_to_char_list "hi!");
  trie
