module type Monoid = sig
  type 'a t

  val zero : 'a t
  val plus : 'a t -> 'a t -> 'a t
end


(** Modules *)

module ListMonoid : Monoid with type 'a t = 'a list = struct
  type 'a t = 'a list

  let zero = []
  let plus = ( @ )
end

module FunctionMonoid : Monoid with type 'a t = 'a -> 'a = struct
  type 'a t = 'a -> 'a

  let zero x = x
  let plus f g x = f (g x)
end

(** Functors *)

module type MonoidOperations = functor (M : Monoid) -> sig
  val fold : 'a M.t list -> 'a M.t
  val mul : int -> 'a M.t -> 'a M.t
end

module MonoidOperations (M : Monoid) = struct
  let fold xs = List.fold_left M.plus M.zero xs
  let rec mul n m = if n = 0 then M.zero else M.plus m (mul (n - 1) m)
end

(* check that we got the type right... *)
module _ : MonoidOperations = MonoidOperations

module FlipMonoid (M : Monoid) : Monoid with type 'a t = 'a M.t = struct
  type 'a t = 'a M.t

  let zero = M.zero
  let plus x1 x2 = M.plus x2 x1
end

module OptionMonoid (M : Monoid) : Monoid with type 'a t = 'a M.t option =
struct
  type 'a t = 'a M.t option

  let zero = None

  let plus m1 m2 =
    match (m1, m2) with
    | Some x1, Some x2 -> Some (M.plus x1 x2)
    | None, Some x | Some x, None -> Some x
    | None, None -> None
end

module PairMonoid (L : Monoid) (R : Monoid) :
  Monoid with type 'a t = 'a L.t * 'a R.t = struct
  type 'a t = 'a L.t * 'a R.t

  let zero = (L.zero, R.zero)
  let plus (a1, b1) (a2, b2) = (L.plus a1 a2, R.plus b1 b2)
end

module PairListFlippedListMonoid : Monoid with type 'a t = ('a list * 'a list) =
  PairMonoid (ListMonoid) (FlipMonoid (ListMonoid))
